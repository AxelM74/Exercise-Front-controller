<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplicar</title>
</head>

<body>

    <h1>Aplicar</h1>

    <?= $aplicar ?>

</body>

</html>