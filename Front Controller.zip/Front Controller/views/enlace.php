<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enlace</title>
</head>

<body>

    <h1>Enlace</h1>

    <?= $enlace ?>

</body>

</html>