<?php

function invocarControlador ($controlador)
{
    require_once "controllers/{$controlador}.php";
}


$seccion = $_GET["page"] ?? 'inicio';

$mapeoPaginas = [
    'inicio' => 'inicioControlador',
    'aplicar' => 'aplicarControlador',
    'enlace' => 'enlaceControlador',
];

$controlador = $mapeoPaginas[$seccion] ?? null;

if ($controlador) {
    
    invocarControlador($controlador);

    $funcion = 'mostrarVista';
    if (function_exists($funcion)) {
        $funcion();
    } else {
        http_response_code(404);
        echo "Página no encontrada";
    }
} else {
    http_response_code(404);
    echo "Página no encontrada";
}
