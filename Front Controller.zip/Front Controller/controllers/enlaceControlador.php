<?php

function mostrarVista()
{

    $enlace = obtenerEnlace();

    include_once("views/enlace.php");
}

function obtenerEnlace()
{

    $enlace = "<a href='?page=inicio'>Inicio</a>
            <a href='?page=aplicar'>Aplicar</a>";

    return $enlace;
}
