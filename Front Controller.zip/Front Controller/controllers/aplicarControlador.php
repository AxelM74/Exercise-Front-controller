<?php

function mostrarVista()
{

    $aplicar = obtenerAplicar();

    include_once("views/aplicar.php");
}

function obtenerAplicar()
{

    $aplicar = "<a href='?page=inicio'>Inicio</a>
            <a href='?page=enlace'>Enlace</a>";
    return $aplicar;
}
