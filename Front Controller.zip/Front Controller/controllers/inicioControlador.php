<?php

function mostrarVista()
{
    
    $inicio = obtenerInicio();

    include_once("views/inicio.php");
}

function obtenerInicio()
{

    $inicio = "<a href='?page=aplicar'>Aplicar</a>
            <a href='?page=enlace'>Enlace</a>";
    return $inicio;
}
